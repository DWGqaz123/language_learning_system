package com.hdu.language_learning_system.exam.entity;

import com.hdu.language_learning_system.exam.converter.AnswerListConverter;
import com.hdu.language_learning_system.exam.dto.StudentAnswerDTO;
import com.hdu.language_learning_system.user.entity.User;
import jakarta.persistence.*;
import lombok.Data;

import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name = "student_exam_records")
@Data
public class StudentExamRecord {

    @EmbeddedId
    private StudentExamRecordId id; // studentId + examId 作为复合主键

    @ManyToOne
    @MapsId("studentId")
    @JoinColumn(name = "student_id")
    private User student;

    @ManyToOne
    @MapsId("examId")
    @JoinColumn(name = "exam_id")
    private MockExam exam;

    @Convert(converter = AnswerListConverter.class)
    @Column(name = "answers_json", columnDefinition = "TEXT")
    private List<StudentAnswerDTO> answersJson;

    private Integer totalScore;
    private Integer subjectiveScore;
    private Integer objectiveScore;
    private String teacherComment;
    private String assistantComment;
    private Timestamp completedTime;
}
