package com.hdu.language_learning_system.exam.dto;

import lombok.Data;


@Data
public class QuestionDTO {
    private String questionId;
    private String questionText;
    private String type; // 主观 or 客观
    private String optionA;
    private String optionB;
    private String optionC;
    private String optionD;
    private String correctAnswers;
    private Integer score;
}