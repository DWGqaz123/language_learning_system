package com.hdu.language_learning_system.exam.converter;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdu.language_learning_system.exam.dto.QuestionDTO;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

import java.util.List;

@Converter
public class QuestionListConverter implements AttributeConverter<List<QuestionDTO>, String> {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public String convertToDatabaseColumn(List<QuestionDTO> questions) {
        try {
            return objectMapper.writeValueAsString(questions);
        } catch (Exception e) {
            throw new RuntimeException("转换 QuestionDTO 列表为 JSON 失败", e);
        }
    }

    @Override
    public List<QuestionDTO> convertToEntityAttribute(String json) {
        try {
            return objectMapper.readValue(json, new TypeReference<List<QuestionDTO>>() {});
        } catch (Exception e) {
            throw new RuntimeException("将 JSON 转换为 QuestionDTO 列表失败", e);
        }
    }
}