package com.hdu.language_learning_system.exam.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class StudentAnswerDTO implements Serializable {
    private String questionId;
    private String answer;
}