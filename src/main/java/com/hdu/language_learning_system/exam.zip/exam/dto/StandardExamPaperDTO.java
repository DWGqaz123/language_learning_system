package com.hdu.language_learning_system.exam.dto;

import lombok.Data;

import java.util.List;

@Data
public class StandardExamPaperDTO {
    private String paperName;
    private String examType;
    private List<QuestionDTO> paperContent;           // 修改为 List
    private List<StudentAnswerDTO> objectiveAnswersJson; // 修改为 List
}