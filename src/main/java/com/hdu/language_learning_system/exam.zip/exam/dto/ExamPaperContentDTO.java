package com.hdu.language_learning_system.exam.dto;

import lombok.Data;

import java.util.List;

@Data
public class ExamPaperContentDTO {
    private Integer paperId;
    private String paperName;
    private List<QuestionDTO> paperContent;
}