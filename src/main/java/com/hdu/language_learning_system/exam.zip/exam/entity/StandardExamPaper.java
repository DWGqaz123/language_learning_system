package com.hdu.language_learning_system.exam.entity;

import com.hdu.language_learning_system.exam.converter.AnswerListConverter;
import com.hdu.language_learning_system.exam.converter.QuestionListConverter;
import com.hdu.language_learning_system.exam.dto.QuestionDTO;
import com.hdu.language_learning_system.exam.dto.StudentAnswerDTO;
import jakarta.persistence.*;
import lombok.Data;

import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name = "standard_exam_papers")
@Data
public class StandardExamPaper {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer paperId;

    private String paperName;      // eg. 托福模拟1套
    private String examType;       // 托福 / 雅思 / GRE 等
    private Timestamp createdTime;
    @Convert(converter = QuestionListConverter.class)
    @Column(name = "paper_content", columnDefinition = "TEXT")
    private List<QuestionDTO> paperContent; // 改为 List<QuestionDTO>

    @Convert(converter = AnswerListConverter.class)
    @Column(name = "objective_answers_json", columnDefinition = "TEXT")
    private List<StudentAnswerDTO> objectiveAnswersJson; // 统一格式为 List<StudentAnswerDTO>

}