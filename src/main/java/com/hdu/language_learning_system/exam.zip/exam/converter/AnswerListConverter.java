package com.hdu.language_learning_system.exam.converter;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hdu.language_learning_system.exam.dto.StudentAnswerDTO;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

import java.util.List;

@Converter
public class AnswerListConverter implements AttributeConverter<List<StudentAnswerDTO>, String> {

    private final ObjectMapper objectMapper = new ObjectMapper()
            .setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY)
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    @Override
    public String convertToDatabaseColumn(List<StudentAnswerDTO> answers) {
        try {
            System.out.println("【Converter】正在转换为 JSON：" + answers);
            return objectMapper.writeValueAsString(answers);
        } catch (Exception e) {
            e.printStackTrace();  // 打印堆栈
            throw new RuntimeException("转换 StudentAnswerDTO 列表为 JSON 失败", e);
        }
    }

    @Override
    public List<StudentAnswerDTO> convertToEntityAttribute(String json) {
        try {
            return objectMapper.readValue(json, new TypeReference<List<StudentAnswerDTO>>() {});
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("将 JSON 转换为 StudentAnswerDTO 列表失败", e);
        }
    }
}