package com.hdu.language_learning_system.exam.dto;

import lombok.Data;

import java.util.List;

@Data
public class ExamAnswerSubmitDTO {
    private Integer examId;
    private Integer studentId;
    private List<StudentAnswerDTO> answers; // 学员提交的所有答案（含主观题）
}